<?php

$v1=array(1,3,5,9);
$v2=array(2,4,6,10,11,15,17,20);
$vmerge=array(0,0,0,0,0,0,0,0,0,0,0,0);
$i=0;
$j=0;
$z=0;
$controllo=0; //Variabile controllo del vettore di riferimento
$t=0;


while (($z<12) and ($controllo==0)) //Controllo che uno dei due vettori sia pieno e il vettore merge sia finito
{
    if ($v1[$i]<=$v2[$j]) //Se il valore in v1 è minore di quello in v2,vmerge=v1
    {
        $vmerge[$z]=$v1[$i];
        $i++;
            if ($i>=4)
                $controllo=1;
    
    }
    else //Else vmerge=v2
    {
        $vmerge[$z]=$v2[$j];
        $j++;
            if ($j>=4)
                $controllo=2;
    }
$z++;
}

for ($t=$z;$t<12;$t++) //Continuo del merge dopo aver completato 1 vettore
{
    if ($controllo==1)
    {
        $vmerge[$t]=$v2[$j];
        $j++;
    }
    else
    {
    $vmerge[$t]=$v1[$i];
    $i++;
    }
}
for ($z=0;$z<12;$z++) //Stampa del vettore
{
    echo $vmerge[$z]. " ";
}

?>



